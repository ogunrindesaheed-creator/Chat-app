/**
 * Signaling + presence server.
 *
 * Responsibilities
 *  1. Presence      - who is online (in-memory Map keyed by Firebase uid)
 *  2. Chat relay    - broadcast messages / typing events, keep last 100 in memory
 *  3. WebRTC signal - forward offer / answer / ICE candidates between two users
 *
 * Media never touches this server: it only passes small JSON messages so that
 * two browsers can find each other. The video itself flows peer-to-peer.
 */
require('dotenv').config();
const http = require('http');
const express = require('express');
const cors = require('cors');
const { Server } = require('socket.io');

const PORT = process.env.PORT || 4000;
const ORIGINS = (process.env.CLIENT_ORIGIN || 'http://localhost:5173')
  .split(',')
  .map((s) => s.trim());

const app = express();
app.use(cors({ origin: ORIGINS }));
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: ORIGINS } });

/* ------------------------------ Optional auth ----------------------------- */
// If a service account is supplied we verify Firebase ID tokens on connect.
let adminAuth = null;
if (process.env.FIREBASE_SERVICE_ACCOUNT) {
  const admin = require('firebase-admin');
  admin.initializeApp({
    credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)),
  });
  adminAuth = admin.auth();
  console.log('Firebase token verification: ON');
} else {
  console.log('Firebase token verification: OFF (dev mode - do not use in production)');
}

io.use(async (socket, next) => {
  const { token, uid, name } = socket.handshake.auth || {};
  try {
    if (adminAuth) {
      const decoded = await adminAuth.verifyIdToken(token);
      socket.data.user = { uid: decoded.uid, name: name || decoded.email || 'User' };
    } else {
      if (!uid) throw new Error('missing uid');
      socket.data.user = { uid, name: name || 'User' };
    }
    next();
  } catch (err) {
    next(new Error('unauthorized'));
  }
});

/* -------------------------------- In-memory state ------------------------- */
const online = new Map(); // uid -> { uid, name, socketId }
const peers = new Map(); //  uid -> uid of the person they are in a call with
const history = []; //       last 100 chat messages (lost on restart - Firestore is the durable store)

const publicUsers = () => [...online.values()].map(({ uid, name }) => ({ uid, name }));
const broadcastPresence = () => io.emit('presence', publicUsers());
const socketOf = (uid) => online.get(uid)?.socketId;

/** Forward `event` + payload to another user, tagging who it came from. */
function relay(socket, to, event, payload = {}) {
  const target = socketOf(to);
  if (!target) return false;
  const { uid, name } = socket.data.user;
  io.to(target).emit(event, { ...payload, from: uid, fromName: name });
  return true;
}

/* -------------------------------- Connection ------------------------------ */
io.on('connection', (socket) => {
  const user = socket.data.user;
  online.set(user.uid, { ...user, socketId: socket.id });
  broadcastPresence();
  socket.emit('chat:history', history);

  /* ---- Chat relay ---- */
  socket.on('chat:message', (msg) => {
    const entry = { ...msg, uid: user.uid, name: user.name, ts: Date.now() };
    history.push(entry);
    if (history.length > 100) history.shift();
    socket.broadcast.emit('chat:message', entry);
  });
  socket.on('chat:typing', (isTyping) => {
    socket.broadcast.emit('chat:typing', { uid: user.uid, name: user.name, isTyping: !!isTyping });
  });

  /* ---- WebRTC signaling ---- */
  socket.on('call:offer', ({ to, offer }) => {
    if (!relay(socket, to, 'call:offer', { offer })) {
      return socket.emit('call:unavailable', { to });
    }
    peers.set(user.uid, to);
    peers.set(to, user.uid);
  });
  socket.on('call:answer', ({ to, answer }) => relay(socket, to, 'call:answer', { answer }));
  socket.on('call:ice', ({ to, candidate }) => relay(socket, to, 'call:ice', { candidate }));
  socket.on('call:decline', ({ to }) => {
    relay(socket, to, 'call:decline');
    peers.delete(user.uid);
    peers.delete(to);
  });
  socket.on('call:end', ({ to }) => {
    relay(socket, to, 'call:end');
    peers.delete(user.uid);
    peers.delete(to);
  });

  /* ---- Disconnect ---- */
  socket.on('disconnect', () => {
    // Ignore if the same user already reconnected on a newer socket.
    if (online.get(user.uid)?.socketId !== socket.id) return;
    const peer = peers.get(user.uid);
    if (peer) {
      relay(socket, peer, 'call:end');
      peers.delete(peer);
      peers.delete(user.uid);
    }
    online.delete(user.uid);
    broadcastPresence();
  });
});

app.get('/health', (_req, res) => res.json({ ok: true, online: online.size }));
app.get('/api/history', (_req, res) => res.json(history));

server.listen(PORT, () => console.log(`Signaling server listening on :${PORT}`));
