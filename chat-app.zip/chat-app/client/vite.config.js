import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // host: true lets Replit / phones on your LAN reach the dev server
  server: { host: true, port: 5173, allowedHosts: true },
});
