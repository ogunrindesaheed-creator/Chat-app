import { useEffect, useState } from 'react';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { io } from 'socket.io-client';
import { auth, db } from './firebase.js';
import Auth from './components/Auth.jsx';
import Chat from './components/Chat.jsx';

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:4000';

export default function App() {
  const [user, setUser] = useState(undefined); // undefined = still checking, null = signed out
  const [socket, setSocket] = useState(null);

  // 1. Track the Firebase session.
  useEffect(() => onAuthStateChanged(auth, (u) => setUser(u)), []);

  // 2. When signed in: save the profile and open the Socket.IO connection.
  useEffect(() => {
    if (!user) return;
    const name = user.displayName || user.email.split('@')[0];

    setDoc(doc(db, 'users', user.uid), { name, email: user.email, lastSeen: serverTimestamp() }, { merge: true })
      .catch((e) => console.error('Could not save profile', e));

    let s;
    let cancelled = false;
    user.getIdToken().then((token) => {
      if (cancelled) return;
      s = io(SOCKET_URL, { auth: { token, uid: user.uid, name } });
      setSocket(s);
    });
    return () => {
      cancelled = true;
      s?.disconnect();
      setSocket(null);
    };
  }, [user]);

  if (user === undefined) return <div className="splash">Loading…</div>;
  if (!user) return <Auth />;

  return <Chat user={user} socket={socket} onSignOut={() => signOut(auth)} />;
}
