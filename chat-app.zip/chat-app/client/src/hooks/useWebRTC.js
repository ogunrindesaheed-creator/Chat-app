import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * One-to-one video calling over WebRTC. Signaling messages travel through the
 * Socket.IO server; media flows directly between the browsers.
 *
 * callState: 'idle' -> 'calling' (we dialled) | 'incoming' (they dialled) -> 'connected'
 *
 * To support TURN (needed on some mobile / corporate networks) add a server to
 * ICE_SERVERS - see README "Going to production".
 */
const ICE_SERVERS = [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }];

export default function useWebRTC(socket) {
  const [callState, setCallState] = useState('idle');
  const [peer, setPeer] = useState(null); // { uid, name }
  const [localStream, setLocalStream] = useState(null);
  const [remoteStream, setRemoteStream] = useState(null);
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);
  const [callError, setCallError] = useState('');

  const pcRef = useRef(null);
  const localRef = useRef(null);
  const peerRef = useRef(null);
  const incomingOfferRef = useRef(null);
  const queuedIce = useRef([]); // ICE candidates that arrive before the remote description is set

  /** Stop everything and return to idle. */
  const cleanup = useCallback(() => {
    pcRef.current?.close();
    pcRef.current = null;
    localRef.current?.getTracks().forEach((t) => t.stop());
    localRef.current = null;
    peerRef.current = null;
    incomingOfferRef.current = null;
    queuedIce.current = [];
    setLocalStream(null);
    setRemoteStream(null);
    setPeer(null);
    setMicOn(true);
    setCamOn(true);
    setCallState('idle');
  }, []);

  const getMedia = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    localRef.current = stream;
    setLocalStream(stream);
    return stream;
  };

  const createPeerConnection = (peerUid, stream) => {
    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });
    stream.getTracks().forEach((t) => pc.addTrack(t, stream));
    pc.onicecandidate = (e) => {
      if (e.candidate) socket.emit('call:ice', { to: peerUid, candidate: e.candidate });
    };
    pc.ontrack = (e) => setRemoteStream(e.streams[0]);
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'connected') setCallState('connected');
      if (['failed', 'closed'].includes(pc.connectionState)) cleanup();
    };
    pcRef.current = pc;
    return pc;
  };

  const flushIce = async () => {
    for (const c of queuedIce.current) await pcRef.current.addIceCandidate(c).catch(console.error);
    queuedIce.current = [];
  };

  /* ---- Caller side ---- */
  const startCall = async (target) => {
    if (callState !== 'idle' || !socket) return;
    setCallError('');
    try {
      peerRef.current = target;
      setPeer(target);
      setCallState('calling');
      const stream = await getMedia();
      const pc = createPeerConnection(target.uid, stream);
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      socket.emit('call:offer', { to: target.uid, offer });
    } catch (err) {
      setCallError(err.name === 'NotAllowedError' ? 'Allow camera and microphone access to start a call.' : 'Could not start the call.');
      cleanup();
    }
  };

  /* ---- Callee side ---- */
  const acceptCall = async () => {
    const target = peerRef.current;
    const offer = incomingOfferRef.current;
    if (!target || !offer) return;
    setCallError('');
    try {
      const stream = await getMedia();
      const pc = createPeerConnection(target.uid, stream);
      await pc.setRemoteDescription(offer);
      await flushIce();
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      socket.emit('call:answer', { to: target.uid, answer });
      setCallState('connected');
    } catch (err) {
      setCallError(err.name === 'NotAllowedError' ? 'Allow camera and microphone access to answer.' : 'Could not answer the call.');
      socket.emit('call:decline', { to: target.uid });
      cleanup();
    }
  };

  const declineCall = () => {
    if (peerRef.current) socket.emit('call:decline', { to: peerRef.current.uid });
    cleanup();
  };

  const endCall = () => {
    if (peerRef.current) socket.emit('call:end', { to: peerRef.current.uid });
    cleanup();
  };

  const toggleMic = () => {
    localRef.current?.getAudioTracks().forEach((t) => (t.enabled = !t.enabled));
    setMicOn((v) => !v);
  };
  const toggleCam = () => {
    localRef.current?.getVideoTracks().forEach((t) => (t.enabled = !t.enabled));
    setCamOn((v) => !v);
  };

  /* ---- Incoming signaling events ---- */
  useEffect(() => {
    if (!socket) return;

    const onOffer = ({ from, fromName, offer }) => {
      if (peerRef.current) return socket.emit('call:decline', { to: from }); // already busy
      const p = { uid: from, name: fromName };
      peerRef.current = p;
      incomingOfferRef.current = offer;
      setPeer(p);
      setCallState('incoming');
    };
    const onAnswer = async ({ answer }) => {
      if (!pcRef.current) return;
      await pcRef.current.setRemoteDescription(answer);
      await flushIce();
    };
    const onIce = async ({ candidate }) => {
      if (pcRef.current?.remoteDescription) await pcRef.current.addIceCandidate(candidate).catch(console.error);
      else queuedIce.current.push(candidate);
    };
    const onDecline = () => {
      setCallError('Call declined.');
      cleanup();
    };
    const onEnd = () => cleanup();
    const onUnavailable = () => {
      setCallError('That person just went offline.');
      cleanup();
    };

    socket.on('call:offer', onOffer);
    socket.on('call:answer', onAnswer);
    socket.on('call:ice', onIce);
    socket.on('call:decline', onDecline);
    socket.on('call:end', onEnd);
    socket.on('call:unavailable', onUnavailable);
    return () => {
      socket.off('call:offer', onOffer);
      socket.off('call:answer', onAnswer);
      socket.off('call:ice', onIce);
      socket.off('call:decline', onDecline);
      socket.off('call:end', onEnd);
      socket.off('call:unavailable', onUnavailable);
    };
  }, [socket, cleanup]);

  // Release camera if the component unmounts mid-call.
  useEffect(() => cleanup, [cleanup]);

  return {
    callState, peer, localStream, remoteStream, micOn, camOn, callError,
    startCall, acceptCall, declineCall, endCall, toggleMic, toggleCam,
    dismissError: () => setCallError(''),
  };
}
