import { useEffect, useRef } from 'react';

function Video({ stream, muted, label }) {
  const ref = useRef(null);
  useEffect(() => {
    if (ref.current) ref.current.srcObject = stream || null;
  }, [stream]);
  return (
    <figure className="tile">
      <video ref={ref} autoPlay playsInline muted={muted} />
      <figcaption>{label}</figcaption>
    </figure>
  );
}

/** Full-screen call layer: incoming prompt, ringing state, or the two video tiles. */
export default function VideoCall({ call }) {
  const { callState, peer, localStream, remoteStream, micOn, camOn } = call;
  if (callState === 'idle') return null;

  if (callState === 'incoming') {
    return (
      <div className="call-layer">
        <div className="ring-card" role="alertdialog" aria-label="Incoming call">
          <p className="ring-name">{peer?.name} is calling</p>
          <div className="row">
            <button className="primary" onClick={call.acceptCall}>Answer</button>
            <button className="danger" onClick={call.declineCall}>Decline</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="call-layer">
      <div className="tiles">
        {remoteStream ? (
          <Video stream={remoteStream} label={peer?.name} />
        ) : (
          <figure className="tile waiting"><p>Calling {peer?.name}…</p></figure>
        )}
        <Video stream={localStream} muted label="You" />
      </div>
      <div className="controls">
        <button onClick={call.toggleMic} aria-pressed={!micOn}>{micOn ? 'Mute' : 'Unmute'}</button>
        <button onClick={call.toggleCam} aria-pressed={!camOn}>{camOn ? 'Camera off' : 'Camera on'}</button>
        <button className="danger" onClick={call.endCall}>End call</button>
      </div>
    </div>
  );
}
