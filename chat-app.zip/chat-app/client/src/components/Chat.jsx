import { useEffect, useRef, useState } from 'react';
import { addDoc, collection, limit, onSnapshot, orderBy, query, serverTimestamp } from 'firebase/firestore';
import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';
import { db, storage } from '../firebase.js';
import useWebRTC from '../hooks/useWebRTC.js';
import VideoCall from './VideoCall.jsx';

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

export default function Chat({ user, socket, onSignOut }) {
  const name = user.displayName || user.email.split('@')[0];

  const [messages, setMessages] = useState([]);
  const [online, setOnline] = useState([]);
  const [typing, setTyping] = useState({}); // uid -> name
  const [text, setText] = useState('');
  const [progress, setProgress] = useState(null); // upload % or null
  const [notice, setNotice] = useState('');

  const call = useWebRTC(socket);
  const bottomRef = useRef(null);
  const fileRef = useRef(null);
  const typingTimer = useRef(null);

  /* Messages: Firestore is the source of truth (persistent + real-time). */
  useEffect(() => {
    const q = query(collection(db, 'messages'), orderBy('createdAt', 'desc'), limit(100));
    return onSnapshot(
      q,
      (snap) => setMessages(snap.docs.map((d) => ({ id: d.id, ...d.data() })).reverse()),
      (err) => setNotice(`Could not load messages (${err.code}). Check your Firestore rules.`)
    );
  }, []);

  /* Presence + typing indicators come from Socket.IO. */
  useEffect(() => {
    if (!socket) return;
    const onPresence = (list) => setOnline(list);
    const onTyping = ({ uid, name: n, isTyping }) =>
      setTyping((prev) => {
        const next = { ...prev };
        if (isTyping) next[uid] = n;
        else delete next[uid];
        return next;
      });
    socket.on('presence', onPresence);
    socket.on('chat:typing', onTyping);
    socket.on('connect_error', () => setNotice('Cannot reach the signaling server. Chat works, calls and presence do not.'));
    socket.on('connect', () => setNotice(''));
    return () => {
      socket.off('presence', onPresence);
      socket.off('chat:typing', onTyping);
    };
  }, [socket]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  /* ---- Sending ---- */
  const send = async (payload) => {
    await addDoc(collection(db, 'messages'), { uid: user.uid, name, createdAt: serverTimestamp(), text: '', ...payload });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const trimmed = text.trim();
    if (!trimmed) return;
    setText('');
    socket?.emit('chat:typing', false);
    try {
      await send({ text: trimmed });
    } catch {
      setText(trimmed);
      setNotice('Message not sent. Check your connection and try again.');
    }
  };

  const onChange = (e) => {
    setText(e.target.value);
    socket?.emit('chat:typing', true);
    clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => socket?.emit('chat:typing', false), 1500);
  };

  /* ---- Image upload -> Firebase Storage -> message with imageUrl ---- */
  const onFile = (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) return setNotice('Only images can be shared.');
    if (file.size > MAX_IMAGE_BYTES) return setNotice('Images must be under 5 MB.');

    setNotice('');
    const task = uploadBytesResumable(ref(storage, `chat-images/${user.uid}/${Date.now()}-${file.name}`), file);
    task.on(
      'state_changed',
      (s) => setProgress(Math.round((s.bytesTransferred / s.totalBytes) * 100)),
      () => {
        setProgress(null);
        setNotice('Upload failed. Check your Storage rules.');
      },
      async () => {
        const imageUrl = await getDownloadURL(task.snapshot.ref);
        await send({ imageUrl });
        setProgress(null);
      }
    );
  };

  const others = online.filter((u) => u.uid !== user.uid);
  const typingNames = Object.values(typing);
  const busy = call.callState !== 'idle';

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="me">
          <strong>{name}</strong>
          <button className="link" onClick={onSignOut}>Sign out</button>
        </div>
        <h2>Online now ({others.length})</h2>
        <ul className="people">
          {others.length === 0 && <li className="muted">No one else is here yet. Open a second browser to test.</li>}
          {others.map((u) => (
            <li key={u.uid}>
              <span className="dot" aria-hidden="true" />
              <span className="grow">{u.name}</span>
              <button disabled={busy} onClick={() => call.startCall(u)} aria-label={`Video call ${u.name}`}>
                Call
              </button>
            </li>
          ))}
        </ul>
      </aside>

      <main className="room">
        {(notice || call.callError) && (
          <div className="notice" role="status">
            {notice || call.callError}
            <button className="link" onClick={() => { setNotice(''); call.dismissError(); }}>Dismiss</button>
          </div>
        )}

        <div className="messages">
          {messages.length === 0 && <p className="muted center">No messages yet. Say hello.</p>}
          {messages.map((m) => (
            <div key={m.id} className={`msg ${m.uid === user.uid ? 'mine' : ''}`}>
              {m.uid !== user.uid && <span className="author">{m.name}</span>}
              {m.imageUrl && (
                <a href={m.imageUrl} target="_blank" rel="noreferrer">
                  <img src={m.imageUrl} alt={`Shared by ${m.name}`} loading="lazy" />
                </a>
              )}
              {m.text && <p>{m.text}</p>}
              <time>{m.createdAt?.toDate?.().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) ?? 'Sending…'}</time>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        <div className="typing" aria-live="polite">
          {typingNames.length > 0 && `${typingNames.join(', ')} ${typingNames.length > 1 ? 'are' : 'is'} typing…`}
          {progress !== null && `Uploading image… ${progress}%`}
        </div>

        <form className="composer" onSubmit={onSubmit}>
          <input type="file" accept="image/*" hidden ref={fileRef} onChange={onFile} />
          <button type="button" onClick={() => fileRef.current.click()} aria-label="Attach image" disabled={progress !== null}>
            Image
          </button>
          <input value={text} onChange={onChange} placeholder="Write a message" aria-label="Message" maxLength={2000} />
          <button className="primary" disabled={!text.trim()}>Send</button>
        </form>
      </main>

      <VideoCall call={call} />
    </div>
  );
}
