# Huddle: real-time chat + 1:1 video calls

React (Vite) client, Node/Express/Socket.IO server, Firebase for auth, messages and images.

```
chat-app/
├── server/                 Node signaling + presence server
│   ├── index.js
│   └── .env.example
├── client/                 React app (Vite)
│   ├── src/
│   │   ├── firebase.js            Firebase init
│   │   ├── App.jsx                Auth state + Socket.IO connection
│   │   ├── hooks/useWebRTC.js     All WebRTC logic (offer/answer/ICE)
│   │   └── components/            Auth, Chat, VideoCall
│   └── .env.example
├── firestore.rules
└── storage.rules
```

## How it fits together

| Concern | Where it lives |
|---|---|
| Sign-in | Firebase Authentication (email/password) |
| Messages (persistent, real-time) | Firestore `messages` collection, read with `onSnapshot` |
| Images | Firebase Storage `chat-images/{uid}/...`, URL saved in the message |
| Who is online, typing | Socket.IO (in-memory on the server) |
| Video call signaling | Socket.IO relays offer / answer / ICE between two users |
| Video and audio | Direct browser-to-browser (WebRTC) |

The server also keeps the last 100 messages in memory and exposes them at `GET /api/history`
and via the `chat:message` event. The client does not render from it (Firestore is the source
of truth); it is an extension point if you want a Firestore-free mode.

## 1. Firebase setup (5 minutes)

1. [console.firebase.google.com](https://console.firebase.google.com) → **Add project**.
2. **Build → Authentication → Get started → Email/Password → Enable.**
3. **Build → Firestore Database → Create database** (production mode), then paste `firestore.rules` into the **Rules** tab and publish.
4. **Build → Storage → Get started**, then paste `storage.rules` into its **Rules** tab and publish.
   (Storage may require the Blaze plan on newer projects; the free usage tier still applies.)
5. **Project settings → Your apps → Web (`</>`)** → register an app and copy the config values.
6. For the server (optional but recommended before going live): **Project settings → Service accounts → Generate new private key**. Minify the JSON to one line and put it in `FIREBASE_SERVICE_ACCOUNT`.

## 2. Run locally

Two terminals.

```bash
# Terminal 1: server
cd server
cp .env.example .env
npm install
npm run dev          # http://localhost:4000/health

# Terminal 2: client
cd client
cp .env.example .env # fill in the Firebase values
npm install
npm run dev          # http://localhost:5173
```

## 3. Run on Replit

Create **two** Repls (or two folders in one Repl with two shells).

**Server Repl** (Node.js): upload `server/`, run `npm install`, then `npm start`.
In **Secrets** add `CLIENT_ORIGIN` = your client Repl's URL (e.g. `https://my-client.username.repl.co`).
Copy the server's public URL.

**Client Repl** (Vite/React): upload `client/`, add every `VITE_*` value from `.env.example`
in **Secrets**, with `VITE_SOCKET_URL` = the server Repl's URL. Run `npm install && npm run dev`.

Also add your client's domain in Firebase: **Authentication → Settings → Authorized domains**.

## 4. Test it

1. Open the app in two different browsers (or one normal and one incognito window) and create two accounts.
2. Send a text message and an image from one; both appear on the other instantly.
3. Both users appear in each other's **Online now** list.
4. Click **Call** next to the other user, then **Answer** in the other window. Allow camera access.
5. Test mute, camera off, **End call**, and **Decline**.
6. Close one tab mid-call: the other side should end the call automatically.

Camera access requires HTTPS or `localhost`. Replit and most hosts provide HTTPS. For
phone testing over your LAN, use an HTTPS tunnel (e.g. ngrok) rather than a plain IP.

## 5. Deploy

- **Client:** `npm run build` in `client/`, host `dist/` on Firebase Hosting, Netlify or Vercel. Set the `VITE_*` variables at build time.
- **Server:** any host with long-lived WebSocket support (Render, Railway, Fly.io). Set `CLIENT_ORIGIN` to your deployed client URL and `FIREBASE_SERVICE_ACCOUNT`.

## Going to production

- **TURN server.** STUN alone fails for roughly 10-20% of users (strict NATs, some mobile networks). Add a TURN service (Twilio, Metered, or self-hosted coturn) to `ICE_SERVERS` in `client/src/hooks/useWebRTC.js`.
- **Token verification.** With `FIREBASE_SERVICE_ACCOUNT` set the server rejects sockets without a valid Firebase ID token. Without it, anyone can connect claiming any uid.
- **Scaling the server.** Presence is in memory, so run one instance, or add the Socket.IO Redis adapter and move presence to Redis.
- **Tighten rules.** The sample rules let any signed-in user read all messages. Add rooms or direct messages before storing anything private.

## Ideas for expanding

- Rooms / direct messages: add a `roomId` field to messages and filter the Firestore query.
- Group calls: replace the single `RTCPeerConnection` with a map of peers (mesh for <5 people, an SFU such as LiveKit beyond that).
- Read receipts, message deletion, push notifications (Firebase Cloud Messaging), screen sharing (`getDisplayMedia`).
